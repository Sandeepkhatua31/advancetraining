CREATE DATABASE bookstore ;
use bookstore ;
CREATE TABLE `books` (
  `Book_id` varchar(10) NOT NULL,
  `Book_name` varchar(50) NOT NULL,
  `Author` varchar(60) NOT NULL,
  `Price` varchar(10) NOT NULL, 
  constraint pk1 primary key (Book_id) 
);

CREATE TABLE `order_details` (
  `Order_Id` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobileno` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `Order_Date` date NOT NULL,
  `Quantity` varchar(11) NOT NULL,
   constraint pk1 primary key (Order_Id) 
   );

CREATE TABLE `Users` (
  `first_name` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` date NOT NULL
);
 
 insert into books  values ( ' 1 ', 'user programming' , 'basant das' , 400.00 ) ;
 insert into books  values ( ' 2 ', ' advance Java' , "java world'  , 300.00 ) ;
 insert into books  values ( ' 3 ', 'sql in depth' , 'naveeen kurteja' , 150.00 ) ;
 insert into books  values ( ' 4 ', 'first step to success' , 'james bond' , 800.00 ) ;
 insert into books  values ( ' 5', 'what is database ?' , 'john  ', 800.00 ) ;
 insert into books  values ( ' 6 ', 'analog communication' , 'akash gupta ' , 860.00 ) ;
 insert into books  values ( ' 7 ', 'backend expert' , 'ramanad swami ' , 608.00 ) ;
 insert into books  values ( ' 8 ', 'core java : in depth' , 'Herbert Schildt ' , 852.00 ) ;
 insert into books  values ( ' 9 ', 'digital communication' , 'priya kanungo ' , 350.00 ) ;
 insert into books  values ( ' 10 ', 'sql : The Complete References' , ' sakhshi das ' , 850.00 ) ;
 
 
 insert into  Users values ('sandeep ' , 'Talcher' , 'sandeep.321@gmail.com' ,'7381648556 ', 'sandeep@33 ' , '2018-12-05 ' ) ;
 insert into  Users values ('rakesh' , 'ratagarh ' , 'rakesh.123@gmail.com' ,'9937560225' , 'rakesh@44' , '2018-12-05 ' ) ;
 insert into  Users values ('krutika' , 'bhubaneswar ' , 'krutika.012@gmail.com' ,'9938560214' , 'krutika3@44 ' , '2018-12-05 ' ) ;
 insert into  Users values ('jonathon ' , 'Cuttack' , 'jonathon@gmail.com' , '9937260547 ', '	Jonathon@43' , '2018-12-05 ' ) ;
 insert into  Users values ('regaltos ' , 'Athagarh ' , 'regaltos@gmail.com' , '8895361458' , 'Rega@44 ' , '2018-12-05 ' ) ;


 insert into order_details  values ( '1' ,  ' Talcher ' , '7381648556' , 'sandeep ' ,'2018-12-05 ' , '2' );
 insert into order_details  values ( '2' ,  ' Ratagarh ' , '9937560225 ' , ' rakesh ' , '2018-12-05' , '4' );
 insert into order_details  values ( '3' ,  ' Bhubaneswar' , '9938560214' , ' Krutika ' , '2018-12-05' , '6' );
 insert into order_details  values ( '4' ,  ' Cuttack' , '9937260547' ,  'Regaltos' , '2018-12-05 ' , '5' );
 insert into order_details  values ( '5' ,  ' athagarh ' , '8895361458' , 'jonathon ' , '2018-12-05 ' , '3' );
 insert into order_details  values ( '6' ,  ' Patna' , '7381659774' , 'rega ' , '2018-12-05 ' , '2' ); 
 