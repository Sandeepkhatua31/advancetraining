Create database Productdb ;
use Productdb ;
create table Product (ProductID varchar(5) Primary key  ,ProductName Varchar(30) , Product_Price varchar(10) );
select * from  Product ;
 